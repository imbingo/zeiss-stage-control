# V2.7.0 下载包安全检查

检查完成：2026-11-14 20:48（香港时间）。

结论：对指定构建产物，Microsoft Defender 与 ClamAV 均完成扫描且未检出威胁；源码/哈希核对未发现异常。此结果不能保证绝对安全，也不能确定 Chrome 的具体判定原因。

## 检查对象

- 仓库：imbingo/zeiss-stage-control
- 构建：43581509988；源码提交：9e37213fd000a2ffbac12db1def02f0ec24d84bd
- 原始 GitHub Actions 附件 windows-setup.zip，SHA-256：`9717066d12f4ddcec54b976e0c7598226ab448ed48e782097c000273b865d37a`
- 安装包 ZEN_Surface_Tilt_Setup_V2.7.0.exe，SHA-256：`b2ab076780f50a6b5f9f6b8aca8836934b80f144705ab1c022ae3ed4d2934d1b`
- 便携 ZIP 及其完整解压内容。原始 ZIP 与构建元数据匹配；EXE 和便携包与构建 SHA256SUMS.txt 匹配。

## 实际结果

| 检查 | 结果 |
|---|---|
| Defender：原始 ZIP、EXE、便携 ZIP、解压文件 | 扫描完成，退出码 0，关联威胁记录 0 |
| ClamAV：原始 ZIP | 扫描完成，感染文件 0，退出码 0 |
| ClamAV：安装 EXE | 扫描完成，感染文件 0，退出码 0 |
| ClamAV：便携 ZIP | 扫描完成，感染文件 0，退出码 0 |
| ClamAV：解压内容 | 扫描完成，感染文件 0，退出码 0 |
| 静态清单 | 5,396 个文件，204,716,730 字节；无加密条目、越界路径或符号链接 |
| 应用源码一致性 | 与对应提交一致；核对时允许 Windows CRLF/LF 换行差异 |
| 安装 EXE Authenticode | 未签名 |

ClamAV 解压目录统计扫描 5,316 个非空文件；与清单差异的 80 个文件均为空文件。原始 ZIP、便携 ZIP 的归档扫描另外独立完成，没有把容器本身的“1 个文件”统计当作解压文件数量。

Defender：引擎 `1.1.26100.4`，病毒库 `1.463.295.0`，库更新时间为本日。已明确开启归档扫描；自动样本提交设为 NeverSend。使用按需扫描，未运行安装包或包内程序，未开启实时防护作为测试前提。日志见 `defender-archive-report/`。

ClamAV：引擎 `1.5.4`，当日 daily 库 `28183`，3,628,275 个已知签名；官方容器摘要 `sha256:45fe5149fbee5a46509c9848ef20d0c354b7b2323c9369f285939a37cf33422a`。病毒库更新时使用受信任 CA，扫描时禁用网络。首次扫描触发默认时间上限，未作为阴性证据；最终独立重扫时将每个目标时限设为 20 分钟，所有目标完成，未出现 FOUND、ERROR 或超限提示。

Windows 原始报告：https://github.com/imbingo/zeiss-stage-control/actions/runs/43595851503

## 签名与打包观察

95 个运行库二进制通过 Windows 签名验证，签名主体为 Python Software Foundation、The Qt Company 和 Microsoft。49 个二进制没有签名，包含应用安装器及部分第三方扩展。4 个 BAT 返回 UnknownError，属于不支持的 Authenticode 文件类型，不是签名损坏证据。

便携包含 Python 标准库附带的 `ctypes/macholib/fetch_macholib.bat` 开发辅助脚本，文本使用旧 HTTP/SVN 下载地址；它不是应用启动项，也未在本次检查中执行。建议后续精简打包时移除这类不需要的开发文件；没有证据证明它导致本次 Chrome 拦截。

## 结论边界与后续

- 未发现恶意软件证据，不等于绝对无毒，也不能单凭两个引擎阴性就宣布 Chrome 误报。
- 已确认安装器没有可信代码签名；尚未取得 Chrome/Safe Browsing 对该次下载的内部判定详情。
- 正式发行应增加可信 Authenticode 签名和时间戳；如仍被拦截，向 Google 提交复核。不能保证签名后立即不再提示。
- 本次没有将程序上传到 VirusTotal 等第三方样本网站，没有执行被检查的载荷，也没有修改已交付的程序文件。
